SELECT
    `curr`.`bowler_id` AS `bowler_id`,
    `curr`.`team_id` AS `team_id`,
    `curr`.`date` AS `date`,
    (
        (
            (
                COALESCE(`curr`.`game1`, 0) + COALESCE(`curr`.`game2`, 0)
            ) + COALESCE(`curr`.`game3`, 0)
        ) /(
            (
                (
                    CASE WHEN ISNULL(`curr`.`game1`) THEN 0 ELSE 1
                END
            ) +(
                CASE WHEN ISNULL(`curr`.`game2`) THEN 0 ELSE 1
            END
        )
    ) +(
        CASE WHEN ISNULL(`curr`.`game3`) THEN 0 ELSE 1
    END
)
)
) AS `weekly_average`,
(
    (
        SUM(`prev`.`game1`) + SUM(`prev`.`game2`)
    ) + SUM(`prev`.`game3`)
) AS `total_so_far`,
(
    (
        COUNT(`prev`.`game1`) + COUNT(`prev`.`game2`)
    ) + COUNT(`prev`.`game3`)
) AS `count_so_far`,
(
    (
        (
            SUM(`prev`.`game1`) + SUM(`prev`.`game2`)
        ) + SUM(`prev`.`game3`)
    ) /(
        (
            COUNT(`prev`.`game1`) + COUNT(`prev`.`game2`)
        ) + COUNT(`prev`.`game3`)
    )
) AS `average`,
(
    `bowling`.`teams`.`hdcp_basis` - FLOOR(
        (
            `bowling`.`teams`.`hdcp_percent` * FLOOR(
                (
                    (
                        (
                            SUM(`prev`.`game1`) + SUM(`prev`.`game2`)
                        ) + SUM(`prev`.`game3`)
                    ) /(
                        (
                            COUNT(`prev`.`game1`) + COUNT(`prev`.`game2`)
                        ) + COUNT(`prev`.`game3`)
                    )
                )
            )
        )
    )
) AS `hdcp`
FROM
    (
        (
            `bowling`.`bowler_series_including_custom` `curr`
        JOIN `bowling`.`bowler_series_including_custom` `prev`
        ON
            (
                (
                    (
                        `prev`.`date` BETWEEN(`curr`.`date` - INTERVAL 1000 DAY) AND `curr`.`date`
                    ) AND(
                        `curr`.`bowler_id` = `prev`.`bowler_id`
                    ) AND(`curr`.`team_id` = `prev`.`team_id`)
                )
            )
        )
    JOIN `bowling`.`teams` ON
        (
            (
                `curr`.`team_id` = `bowling`.`teams`.`id`
            )
        )
    )
GROUP BY
    `curr`.`date`,
    `curr`.`bowler_id`
ORDER BY
    `curr`.`date`